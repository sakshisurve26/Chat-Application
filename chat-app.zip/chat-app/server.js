// server.js

require('dotenv').config();
const express = require('express');
const http = require('http');
const mongoose = require('mongoose');
const { Server } = require('socket.io');
const path = require('path');

// App setup
const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Middleware
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// MongoDB schema
const messageSchema = new mongoose.Schema({
  username: String,
  message: String,
  timestamp: { type: Date, default: Date.now }
});

const Message = mongoose.model('Message', messageSchema);

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log('✅ Connected to MongoDB Atlas');
  })
  .catch((err) => {
    console.error('❌ MongoDB connection error:', err);
  });

// Socket.io events
io.on('connection', (socket) => {
  console.log('🔌 A user connected');

  // Send previous messages to new user
  Message.find().sort({ timestamp: 1 }).limit(50)
    .then((messages) => {
      const validMessages = messages.filter(msg => msg.username && msg.message);
      socket.emit('previousMessages', validMessages);
    })
    .catch((err) => {
      console.error('❌ Error loading messages:', err);
    });

  // Handle new chat message
  socket.on('chatMessage', async (data) => {
    const newMessage = new Message({
      username: data.username,
      message: data.message
    });

    await newMessage.save();

    io.emit('chat message', {
      _id: newMessage._id,
      username: newMessage.username,
      message: newMessage.message,
      timestamp: newMessage.timestamp
    });
  });

  // ✅ Handle Edit Message (inside connection block)
  socket.on('editMessage', async ({ id, message }) => {
    try {
      const updated = await Message.findByIdAndUpdate(
        id,
        { message },
        { new: true }
      );

      if (updated) {
        io.emit('edit message', {
          _id: updated._id,
          message: updated.message
        });
      }
    } catch (err) {
      console.error('❌ Error editing message:', err);
    }
  });

  // ✅ Handle Delete Message (inside connection block)
  socket.on('deleteMessage', async (id) => {
    try {
      await Message.findByIdAndDelete(id);
      io.emit('delete message', id);
    } catch (err) {
      console.error('❌ Error deleting message:', err);
    }
  });

  socket.on('disconnect', () => {
    console.log('🔌 A user disconnected');
  });
});

// Start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
