// Listen for new messages
socket.on('chatMessage', async (data) => {
  const newMessage = new Message({
    username: data.username,
    message: data.message
  });

  await newMessage.save();

  // Send message to all clients
  io.emit('chat message', newMessage); // Use full message with _id
});

socket.on('delete message', (id) => {
  const msgEl = document.querySelector(`li[data-id="${id}"]`);
  if (msgEl) msgEl.remove();
});
