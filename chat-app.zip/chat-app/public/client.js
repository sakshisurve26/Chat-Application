const socket = io();
const form = document.getElementById('chatForm');
const input = document.getElementById('msgInput');
const messages = document.getElementById('messages');

// Prompt user for name
let username = prompt("Enter your name:") || "User";

// Handle incoming previous messages
socket.on('previousMessages', (msgs) => {
  msgs.forEach(msg => {
    const item = document.createElement('li');
    item.textContent = `${msg.username}: ${msg.message}`;
    messages.appendChild(item);
  });
});

// Handle new chat messages
socket.on('chat message', (msg) => {
  const item = document.createElement('li');
  item.textContent = `${msg.username}: ${msg.message}`;
  messages.appendChild(item);
  window.scrollTo(0, document.body.scrollHeight);
});

// Form submit handler
form.addEventListener('submit', function (e) {
  e.preventDefault();
  if (input.value.trim()) {
    socket.emit('chatMessage', {
      username: username,
      message: input.value
    });
    input.value = '';
  }
});

// Dark mode toggle
const toggleBtn = document.getElementById('darkModeBtn');

toggleBtn.addEventListener('click', () => {
  document.body.classList.toggle('dark');
});
